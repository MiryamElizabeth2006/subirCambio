// ===== VARIABLES GLOBALES =====
let currentUser = null;
let currentDocument = null;
let documents = JSON.parse(localStorage.getItem('documents')) || [];
let currentFile = null;

// ===== INICIALIZACIÓN =====
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Verificar si el usuario está logueado
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    if (isLoggedIn) {
        showMainScreen();
        loadDocuments();
        initializeSidebar();
    } else {
        showLoginScreen();
    }
    
    // Configurar event listeners
    setupEventListeners();
}

// ===== GESTIÓN DE PANTALLAS =====
function showLoginScreen() {
    document.getElementById('login-screen').classList.add('active');
    document.getElementById('main-screen').classList.remove('active');
}

function showMainScreen() {
    document.getElementById('login-screen').classList.remove('active');
    document.getElementById('main-screen').classList.add('active');
    currentUser = { name: 'Administrador' };
}

// ===== CONFIGURACIÓN DE EVENT LISTENERS =====
function setupEventListeners() {
    // Login
    document.getElementById('login-form').addEventListener('submit', handleLogin);
    document.getElementById('logout-btn').addEventListener('click', handleLogout);
    
    // Navegación
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', handleNavigation);
    });
    
    // Subida de archivos
    const uploadArea = document.getElementById('upload-area');
    const fileInput = document.getElementById('file-input');
    
    uploadArea.addEventListener('click', () => fileInput.click());
    uploadArea.addEventListener('dragover', handleDragOver);
    uploadArea.addEventListener('drop', handleFileDrop);
    fileInput.addEventListener('change', handleFileSelect);
    
    // Procesamiento de archivos
    document.getElementById('remove-file').addEventListener('click', removeFile);
    document.getElementById('process-file').addEventListener('click', processFile);
    
    // Tabs de procesamiento
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', handleTabChange);
    });
    
    // Formulario de documento
    document.getElementById('document-form').addEventListener('submit', handleDocumentSave);
    
    // Búsqueda y filtros
    document.getElementById('search-docs').addEventListener('input', handleSearch);
    document.getElementById('filter-type').addEventListener('change', handleFilter);
    
    // Sidebar toggle
    document.getElementById('sidebar-toggle').addEventListener('click', toggleSidebar);
    
    // Modal
    document.getElementById('close-modal').addEventListener('click', closeModal);
    
    // Cerrar modal al hacer clic fuera
    document.getElementById('document-modal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
    
    // Manejar cambio de tamaño de ventana
    window.addEventListener('resize', handleResize);
    
    // Overlay para cerrar sidebar
    document.getElementById('sidebar-overlay').addEventListener('click', function() {
        if (window.innerWidth <= 768) {
            toggleSidebar();
        }
    });
}

// ===== AUTENTICACIÓN =====
function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    // Validación simple (en producción usar backend)
    if (username === 'admin' && password === '123456') {
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('currentUser', JSON.stringify({ name: 'Administrador' }));
        showMainScreen();
        loadDocuments();
        showNotification('Sesión iniciada correctamente', 'success');
    } else {
        showNotification('Usuario o contraseña incorrectos', 'error');
    }
}

function handleLogout() {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('currentUser');
    showLoginScreen();
    showNotification('Sesión cerrada', 'info');
}

// ===== NAVEGACIÓN =====
function handleNavigation(e) {
    const section = e.currentTarget.dataset.section;
    
    // Actualizar navegación activa
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    e.currentTarget.classList.add('active');
    
    // Mostrar sección correspondiente
    document.querySelectorAll('.content-section').forEach(sectionEl => {
        sectionEl.classList.remove('active');
    });
    document.getElementById(section).classList.add('active');
    
    // Actualizar título de la página
    const titles = {
        dashboard: 'Dashboard',
        upload: 'Subir Documento',
        documents: 'Documentos',
        processing: 'Procesamiento'
    };
    document.getElementById('page-title').textContent = titles[section];
    
    // Cerrar sidebar en móviles después de navegar
    if (window.innerWidth <= 768) {
        toggleSidebar();
    }
}

// ===== TOGGLE SIDEBAR =====
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    const isCollapsed = sidebar.classList.contains('collapsed');
    
    if (isCollapsed) {
        sidebar.classList.remove('collapsed');
        sidebar.classList.add('open');
        // Mostrar overlay solo en móviles
        if (window.innerWidth <= 768) {
            overlay.classList.remove('hidden');
        }
    } else {
        sidebar.classList.add('collapsed');
        sidebar.classList.remove('open');
        overlay.classList.add('hidden');
    }
    
    // Guardar estado en localStorage
    localStorage.setItem('sidebarCollapsed', !isCollapsed);
}

function initializeSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const sidebarCollapsed = localStorage.getItem('sidebarCollapsed');
    
    // En pantallas pequeñas, el sidebar siempre empieza colapsado
    if (window.innerWidth <= 768) {
        sidebar.classList.add('collapsed');
    } else {
        // En pantallas grandes, recordar el estado anterior
        if (sidebarCollapsed === 'true') {
            sidebar.classList.add('collapsed');
        }
    }
}

function handleResize() {
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    
    // En pantallas pequeñas, asegurar que el sidebar esté colapsado
    if (window.innerWidth <= 768) {
        sidebar.classList.add('collapsed');
        sidebar.classList.remove('open');
        overlay.classList.add('hidden');
    } else {
        // En pantallas grandes, remover la clase 'open' que es solo para móviles
        sidebar.classList.remove('open');
        overlay.classList.add('hidden');
    }
}

// ===== SUBIDA DE ARCHIVOS =====
function handleDragOver(e) {
    e.preventDefault();
    e.currentTarget.classList.add('dragover');
}

function handleFileDrop(e) {
    e.preventDefault();
    e.currentTarget.classList.remove('dragover');
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        handleFile(files[0]);
    }
}

function handleFileSelect(e) {
    const file = e.target.files[0];
    if (file) {
        handleFile(file);
    }
}

function handleFile(file) {
    // Validar tipo de archivo
    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
    if (!allowedTypes.includes(file.type)) {
        showNotification('Tipo de archivo no soportado. Use PDF, JPG o PNG', 'error');
        return;
    }
    
    // Validar tamaño (máximo 10MB)
    if (file.size > 10 * 1024 * 1024) {
        showNotification('El archivo es demasiado grande. Máximo 10MB', 'error');
        return;
    }
    
    currentFile = file;
    showFilePreview(file);
    showNotification('Archivo cargado correctamente', 'success');
}

function showFilePreview(file) {
    const preview = document.getElementById('file-preview');
    const previewImg = document.getElementById('preview-img');
    const fileName = document.getElementById('file-name');
    const fileSize = document.getElementById('file-size');
    const fileType = document.getElementById('file-type');
    
    // Mostrar información del archivo
    fileName.textContent = file.name;
    fileSize.textContent = formatFileSize(file.size);
    fileType.textContent = file.type;
    
    // Mostrar vista previa si es imagen
    if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
        };
        reader.readAsDataURL(file);
    } else {
        previewImg.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgdmlld0JveD0iMCAwIDIwMCAyMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIyMDAiIGhlaWdodD0iMjAwIiBmaWxsPSIjMzMzMzMzIi8+CjxwYXRoIGQ9Ik01MCA1MEgxNTBWMTUwSDUwVjUwWiIgZmlsbD0iIzY2NjY2NiIvPgo8cGF0aCBkPSJNNzAgNzBIMTMwVjkwSDcwVjcwWiIgZmlsbD0iIzk5OTk5OSIvPgo8cGF0aCBkPSJNNzAgMTAwSDEzMFYxMjBINzBWMTAwWiIgZmlsbD0iIzk5OTk5OSIvPgo8cGF0aCBkPSJNNzAgMTMwSDEzMFYxNTBINzBWMTMwWiIgZmlsbD0iIzk5OTk5OSIvPgo8L3N2Zz4K';
    }
    
    preview.classList.remove('hidden');
}

function removeFile() {
    currentFile = null;
    document.getElementById('file-preview').classList.add('hidden');
    document.getElementById('file-input').value = '';
    showNotification('Archivo eliminado', 'info');
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// ===== PROCESAMIENTO DE DOCUMENTOS =====
function processFile() {
    if (!currentFile) {
        showNotification('No hay archivo para procesar', 'error');
        return;
    }
    
    // Simular procesamiento OCR
    const statusBadge = document.getElementById('processing-status');
    statusBadge.textContent = 'Procesando...';
    statusBadge.className = 'status-badge processing';
    
    showNotification('Iniciando procesamiento OCR...', 'info');
    
    // Simular tiempo de procesamiento
    setTimeout(() => {
        statusBadge.textContent = 'Completado';
        statusBadge.className = 'status-badge completed';
        
        // Simular texto extraído
        const extractedText = simulateOCRText();
        document.getElementById('extracted-textarea').value = extractedText;
        
        // Mostrar documento en la vista original
        if (currentFile.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('document-img').src = e.target.result;
            };
            reader.readAsDataURL(currentFile);
        }
        
        // Cambiar a la sección de procesamiento
        document.querySelector('[data-section="processing"]').click();
        
        showNotification('Documento procesado correctamente', 'success');
    }, 3000);
}

function simulateOCRText() {
    const sampleTexts = [
        `FACTURA ELECTRÓNICA
Número: F001-2024-00012345
Fecha: 15/01/2024

EMPRESA EJEMPLO S.A.
RUC: 20123456789
Dirección: Av. Principal 123, Lima

CLIENTE:
Juan Pérez
DNI: 12345678
Dirección: Calle Secundaria 456

DETALLE:
1. Servicio de consultoría - S/. 1,500.00
2. Desarrollo de software - S/. 3,200.00
3. Capacitación - S/. 800.00

Subtotal: S/. 5,500.00
IGV (18%): S/. 990.00
TOTAL: S/. 6,490.00

Forma de pago: Transferencia bancaria
Vencimiento: 30 días`,

        `RECIBO DE PAGO
Número: R001-2024-00098765
Fecha: 20/01/2024

Recibí de: María González
La suma de: S/. 2,500.00
Por concepto de: Pago de servicios profesionales

Monto en letras: DOS MIL QUINIENTOS Y 00/100 SOLES

Firma: _________________
DNI: 87654321`,

        `CONTRATO DE ARRENDAMIENTO
Contrato N°: C001-2024
Fecha: 10/01/2024

ENTRE LOS SUSCRITOS:
Arrendador: Carlos López
DNI: 11223344
Dirección: Av. Los Pinos 789

Arrendatario: Ana Martínez
DNI: 55667788
Dirección: Calle Real 321

OBJETO:
Arrendamiento de oficina ubicada en Av. Los Pinos 789, 3er piso.

PLAZO: 12 meses
MONTO MENSUAL: S/. 3,000.00

Firmas:
Arrendador: _________________
Arrendatario: _________________`
    ];
    
    return sampleTexts[Math.floor(Math.random() * sampleTexts.length)];
}

// ===== GESTIÓN DE TABS =====
function handleTabChange(e) {
    const tabName = e.currentTarget.dataset.tab;
    
    // Actualizar botones activos
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    e.currentTarget.classList.add('active');
    
    // Mostrar contenido correspondiente
    document.querySelectorAll('.tab-pane').forEach(pane => {
        pane.classList.remove('active');
    });
    document.getElementById(tabName + '-tab').classList.add('active');
}

// ===== FORMULARIO DE DOCUMENTO =====
function handleDocumentSave(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const documentData = {
        id: Date.now(),
        name: currentFile ? currentFile.name : 'Documento sin nombre',
        type: formData.get('doc-type') || document.getElementById('doc-type').value,
        date: formData.get('doc-date') || document.getElementById('doc-date').value,
        number: formData.get('doc-number') || document.getElementById('doc-number').value,
        amount: formData.get('doc-amount') || document.getElementById('doc-amount').value,
        description: formData.get('doc-description') || document.getElementById('doc-description').value,
        tags: formData.get('doc-tags') || document.getElementById('doc-tags').value,
        extractedText: document.getElementById('extracted-textarea').value,
        status: 'Procesado',
        createdAt: new Date().toISOString(),
        file: currentFile ? {
            name: currentFile.name,
            size: currentFile.size,
            type: currentFile.type
        } : null
    };
    
    // Guardar documento
    documents.push(documentData);
    localStorage.setItem('documents', JSON.stringify(documents));
    
    // Limpiar formulario
    e.target.reset();
    removeFile();
    
    showNotification('Documento guardado correctamente', 'success');
    
    // Cambiar a la sección de documentos
    document.querySelector('[data-section="documents"]').click();
}

// ===== GESTIÓN DE DOCUMENTOS =====
function loadDocuments() {
    const tbody = document.getElementById('documents-tbody');
    tbody.innerHTML = '';
    
    documents.forEach(doc => {
        const row = createDocumentRow(doc);
        tbody.appendChild(row);
    });
}

function createDocumentRow(doc) {
    const row = document.createElement('tr');
    
    row.innerHTML = `
        <td>
            <span class="document-name" onclick="viewDocument(${doc.id})">${doc.name}</span>
        </td>
        <td>
            <span class="document-type ${doc.type}">${doc.type}</span>
        </td>
        <td>${formatDate(doc.date)}</td>
        <td>${doc.number || '-'}</td>
        <td>${doc.amount ? 'S/. ' + parseFloat(doc.amount).toFixed(2) : '-'}</td>
        <td>
            <span class="status-badge completed">${doc.status}</span>
        </td>
        <td>
            <div class="document-actions">
                <button class="action-btn view" onclick="viewDocument(${doc.id})">Ver</button>
                <button class="action-btn edit" onclick="editDocument(${doc.id})">Editar</button>
                <button class="action-btn delete" onclick="deleteDocument(${doc.id})">Eliminar</button>
            </div>
        </td>
    `;
    
    return row;
}

function viewDocument(id) {
    const doc = documents.find(d => d.id === id);
    if (!doc) return;
    
    const modal = document.getElementById('document-modal');
    const modalBody = document.getElementById('modal-body');
    
    modalBody.innerHTML = `
        <div class="document-details">
            <div class="detail-row">
                <strong>Nombre:</strong> ${doc.name}
            </div>
            <div class="detail-row">
                <strong>Tipo:</strong> <span class="document-type ${doc.type}">${doc.type}</span>
            </div>
            <div class="detail-row">
                <strong>Fecha:</strong> ${formatDate(doc.date)}
            </div>
            <div class="detail-row">
                <strong>Número:</strong> ${doc.number || '-'}
            </div>
            <div class="detail-row">
                <strong>Monto:</strong> ${doc.amount ? 'S/. ' + parseFloat(doc.amount).toFixed(2) : '-'}
            </div>
            <div class="detail-row">
                <strong>Descripción:</strong> ${doc.description || '-'}
            </div>
            <div class="detail-row">
                <strong>Etiquetas:</strong> ${doc.tags || '-'}
            </div>
            <div class="detail-row">
                <strong>Estado:</strong> <span class="status-badge completed">${doc.status}</span>
            </div>
            <div class="detail-row">
                <strong>Texto Extraído:</strong>
                <div class="extracted-text-preview">
                    <pre>${doc.extractedText || 'No hay texto extraído'}</pre>
                </div>
            </div>
        </div>
    `;
    
    modal.classList.remove('hidden');
}

function editDocument(id) {
    const doc = documents.find(d => d.id === id);
    if (!doc) return;
    
    // Llenar formulario con datos del documento
    document.getElementById('doc-type').value = doc.type;
    document.getElementById('doc-date').value = doc.date;
    document.getElementById('doc-number').value = doc.number || '';
    document.getElementById('doc-amount').value = doc.amount || '';
    document.getElementById('doc-description').value = doc.description || '';
    document.getElementById('doc-tags').value = doc.tags || '';
    document.getElementById('extracted-textarea').value = doc.extractedText || '';
    
    // Cambiar a la sección de procesamiento
    document.querySelector('[data-section="processing"]').click();
    
    showNotification('Documento cargado para edición', 'info');
}

function deleteDocument(id) {
    if (confirm('¿Está seguro de que desea eliminar este documento?')) {
        documents = documents.filter(d => d.id !== id);
        localStorage.setItem('documents', JSON.stringify(documents));
        loadDocuments();
        showNotification('Documento eliminado', 'success');
    }
}

function closeModal() {
    document.getElementById('document-modal').classList.add('hidden');
}

// ===== BÚSQUEDA Y FILTROS =====
function handleSearch(e) {
    const searchTerm = e.target.value.toLowerCase();
    const rows = document.querySelectorAll('#documents-tbody tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
}

function handleFilter(e) {
    const filterType = e.target.value;
    const rows = document.querySelectorAll('#documents-tbody tr');
    
    rows.forEach(row => {
        const typeCell = row.querySelector('.document-type');
        const type = typeCell ? typeCell.textContent.toLowerCase() : '';
        
        if (!filterType || type === filterType) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// ===== UTILIDADES =====
function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('es-ES');
}

function showNotification(message, type = 'info') {
    const notifications = document.getElementById('notifications');
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    notifications.appendChild(notification);
    
    // Remover notificación después de 5 segundos
    setTimeout(() => {
        notification.remove();
    }, 5000);
}

// ===== FUNCIONES ADICIONALES =====
function copyText() {
    const textarea = document.getElementById('extracted-textarea');
    textarea.select();
    document.execCommand('copy');
    showNotification('Texto copiado al portapapeles', 'success');
}

// Agregar event listener para el botón de copiar texto
document.addEventListener('click', function(e) {
    if (e.target.textContent === 'Copiar Texto') {
        copyText();
    }
});
