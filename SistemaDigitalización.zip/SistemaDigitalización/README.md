# Sistema de Digitalización de Documentos

Un sistema completo de digitalización de documentos desarrollado con HTML, CSS y JavaScript puro, sin dependencias externas.

## 🚀 Características

### ✨ Funcionalidades Principales
- **Autenticación de usuarios** con validación básica
- **Dashboard interactivo** con estadísticas y actividad reciente
- **Subida de documentos** con drag & drop (PDF, JPG, PNG)
- **Vista previa** de archivos cargados
- **Procesamiento simulado de OCR** con texto extraído
- **Formulario de verificación** y edición de datos extraídos
- **Gestión completa de documentos** (ver, editar, eliminar)
- **Búsqueda y filtros** por tipo de documento
- **Almacenamiento local** con localStorage
- **Diseño responsivo** para todos los dispositivos

### 🎨 Diseño Moderno
- **Tema oscuro** con fondo negro/gris oscuro
- **Acentos azules** para botones e interacciones
- **Tipografía Inter** para máxima legibilidad
- **Animaciones suaves** y transiciones elegantes
- **Interfaz intuitiva** con navegación lateral
- **Notificaciones** en tiempo real

## 📁 Estructura del Proyecto

```
SistemaDigitalización/
├── index.html          # Página principal con todas las pantallas
├── style.css           # Estilos modernos y responsivos
├── script.js           # Lógica completa del sistema
└── README.md           # Este archivo
```

## 🛠️ Instalación y Uso

### Requisitos
- Navegador web moderno (Chrome, Firefox, Safari, Edge)
- No requiere servidor web (funciona localmente)

### Pasos de Instalación
1. Descarga o clona el proyecto
2. Abre `index.html` en tu navegador
3. ¡Listo! El sistema está funcionando

### Credenciales de Acceso
- **Usuario:** `admin`
- **Contraseña:** `123456`

## 📋 Guía de Uso

### 1. Inicio de Sesión
- Ingresa las credenciales proporcionadas
- El sistema recordará tu sesión hasta que cierres sesión

### 2. Dashboard
- Visualiza estadísticas generales del sistema
- Revisa la actividad reciente
- Navega entre las diferentes secciones

### 3. Subir Documentos
- Ve a la sección "Subir Documento"
- Arrastra y suelta archivos o haz clic para seleccionar
- Formatos soportados: PDF, JPG, PNG
- Tamaño máximo: 10MB

### 4. Procesamiento
- Haz clic en "Procesar Documento"
- El sistema simulará el procesamiento OCR
- Revisa el texto extraído en la pestaña correspondiente
- Completa el formulario con los datos del documento

### 5. Gestión de Documentos
- Ve a la sección "Documentos"
- Busca documentos por nombre
- Filtra por tipo de documento
- Ver, editar o eliminar documentos existentes

## 🔧 Funcionalidades Técnicas

### Navegación
- Cambio entre secciones sin recargar la página
- Navegación lateral con indicadores visuales
- Títulos dinámicos según la sección activa

### Subida de Archivos
- Drag & drop nativo del navegador
- Validación de tipos de archivo
- Validación de tamaño
- Vista previa de imágenes
- Información detallada del archivo

### Procesamiento Simulado
- Simulación de OCR con textos de ejemplo
- Estados de procesamiento (Pendiente, Procesando, Completado)
- Tabs para diferentes vistas del documento
- Área editable para el texto extraído

### Almacenamiento
- Uso de localStorage para persistencia
- Estructura de datos JSON
- Gestión de sesiones de usuario
- Backup automático de documentos

### Interfaz de Usuario
- Notificaciones toast para feedback
- Modales para detalles de documentos
- Formularios con validación
- Tablas responsivas
- Botones con estados hover

## 🎯 Tipos de Documentos Soportados

- **Facturas:** Con campos para número, fecha, monto, cliente
- **Recibos:** Información de pago y conceptos
- **Contratos:** Datos de las partes y términos
- **Identificaciones:** Documentos de identidad
- **Otros:** Documentos genéricos

## 📱 Responsive Design

El sistema está completamente optimizado para:
- **Desktop:** Navegación lateral completa
- **Tablet:** Adaptación automática del layout
- **Mobile:** Navegación colapsable y elementos apilados

## 🔒 Seguridad

### Notas Importantes
- Este es un sistema de demostración
- La autenticación es básica (solo frontend)
- Los datos se almacenan en localStorage del navegador
- Para producción, implementar:
  - Backend con autenticación real
  - Base de datos segura
  - Validación de archivos en servidor
  - Encriptación de datos sensibles

## 🚀 Próximas Mejoras

### Funcionalidades Planificadas
- [ ] Integración con APIs de OCR reales
- [ ] Exportación de documentos a PDF
- [ ] Sistema de etiquetas avanzado
- [ ] Búsqueda por contenido de texto
- [ ] Historial de cambios
- [ ] Backup y sincronización en la nube
- [ ] Múltiples usuarios y permisos
- [ ] API REST para integración

### Mejoras de UX
- [ ] Modo claro/oscuro
- [ ] Personalización de temas
- [ ] Atajos de teclado
- [ ] Tutorial interactivo
- [ ] Modo offline

## 🐛 Solución de Problemas

### Problemas Comunes

**No se cargan los archivos:**
- Verifica que el archivo sea PDF, JPG o PNG
- Asegúrate de que no exceda 10MB
- Intenta con un archivo diferente

**No se guardan los documentos:**
- Verifica que el navegador soporte localStorage
- Limpia el caché del navegador
- Intenta en modo incógnito

**Problemas de visualización:**
- Actualiza el navegador a la última versión
- Verifica que JavaScript esté habilitado
- Intenta con otro navegador

## 📄 Licencia

Este proyecto es de código abierto y está disponible bajo la licencia MIT.

## 🤝 Contribuciones

Las contribuciones son bienvenidas. Por favor:
1. Fork el proyecto
2. Crea una rama para tu feature
3. Commit tus cambios
4. Push a la rama
5. Abre un Pull Request

## 📞 Soporte

Para soporte técnico o preguntas:
- Revisa la documentación
- Abre un issue en el repositorio
- Contacta al equipo de desarrollo

---

**Desarrollado con ❤️ usando HTML, CSS y JavaScript puro**
